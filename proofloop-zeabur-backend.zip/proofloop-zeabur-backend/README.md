# PROOFLOOP Backend Starter

This starter API is prepared for cloud deployment. It includes:

- `GET /` — simple alive message
- `GET /api/health` — health check
- `POST /api/test` — echoes a JSON request body

## Run locally

```bash
npm install
npm start
```

Open `http://127.0.0.1:3000/api/health` while the server is running.

## Deploy settings

- Runtime: Node.js 20 or newer
- Install/build command: `npm install`
- Start command: `npm start`
- Port: reads `process.env.PORT`
- Optional environment variable: `CORS_ORIGIN` (comma-separated exact frontend origins). Leave unset for the initial demo; before public production use, set this to your actual frontend origin.

## Important

This is a starter backend, not yet the AI app-building engine. Do not put model/API secrets in frontend JavaScript or commit secrets to GitHub. Add real AI-generation routes and usage limits before inviting public users.
