const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

// During initial deployment, this allows browser requests from the frontend.
// After the frontend has a stable public URL, set CORS_ORIGIN in the host's
// environment settings to that exact origin, e.g. https://your-site.example.
const allowedOrigins = (process.env.CORS_ORIGIN || "*")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(
  cors({
    origin(origin, callback) {
      // Requests without an Origin header include curl and server-to-server calls.
      if (!origin || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error("Origin is not allowed by CORS"));
    },
  })
);

app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => {
  res.type("text/plain").send("PROOFLOOP backend is alive!");
});

app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    project: "PROOFLOOP",
    message: "Backend is running successfully!",
    timestamp: new Date().toISOString(),
  });
});

app.post("/api/test", (req, res) => {
  res.json({
    status: "ok",
    received: req.body ?? {},
    message: "Your request reached PROOFLOOP!",
  });
});

app.use((_req, res) => {
  res.status(404).json({
    status: "error",
    message: "API route not found",
  });
});

app.use((err, _req, res, _next) => {
  if (err && err.message === "Origin is not allowed by CORS") {
    return res.status(403).json({ status: "error", message: err.message });
  }
  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({ status: "error", message: "Invalid JSON body" });
  }
  console.error("PROOFLOOP backend error:", err);
  return res.status(500).json({ status: "error", message: "Internal server error" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`PROOFLOOP backend running on port ${PORT}`);
});
